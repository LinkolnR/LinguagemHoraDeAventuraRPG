# LogCompProject
Repositório criado para executar as tarefas da disciplina de LogComp

# imagem do diagrama atual:

![Diagrama atual](Diagrama_atual.png)


----
# Status dos testes
![git status]( http://3.129.230.99/svg/LinkolnR/LogCompProject/)
